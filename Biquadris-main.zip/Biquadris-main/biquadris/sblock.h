#ifndef SBLOCK_H
#define SBLOCK_H

#include "block.h"

class SBlock: public Block {
public:
    SBlock(int level);
};

#endif
