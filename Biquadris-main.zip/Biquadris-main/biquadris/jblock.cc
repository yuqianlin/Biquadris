#include "jblock.h"

JBlock::JBlock(int level): Block{level, 'J', {std::make_pair(0, 0), std::make_pair(0, 1), std::make_pair(1, 1), std::make_pair(2, 1)}, {0, 3, 4, 5}} {}
